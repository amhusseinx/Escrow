# دليل نشر موقع EscrowMarket على سيرفر خاص

هذا الدليل يشرح كيفية نشر موقع EscrowMarket على سيرفر خاص بك.

## متطلبات النظام

- Node.js (الإصدار 16 أو أحدث)
- Python 3.8 أو أحدث
- قاعدة بيانات (SQLite للتطوير، PostgreSQL أو MySQL للإنتاج)
- مدير حزم npm أو pnpm أو yarn

## هيكل المشروع

```
full_escrow_project/
├── frontend/         # الواجهة الأمامية (React)
├── backend/          # الواجهة الخلفية (Flask)
└── README.md         # معلومات عامة عن المشروع
```

## خطوات النشر

### 1. إعداد الواجهة الخلفية (Backend)

1. انتقل إلى مجلد الواجهة الخلفية:
   ```bash
   cd backend
   ```

2. أنشئ بيئة افتراضية لـ Python:
   ```bash
   python -m venv venv
   ```

3. قم بتنشيط البيئة الافتراضية:
   - على Linux/macOS:
     ```bash
     source venv/bin/activate
     ```
   - على Windows:
     ```bash
     venv\Scripts\activate
     ```

4. قم بتثبيت المتطلبات:
   ```bash
   pip install -r requirements.txt
   ```

5. قم بتعديل ملف التكوين (إذا لزم الأمر):
   - للإنتاج، قم بتعديل إعدادات قاعدة البيانات في `src/main.py`
   - يمكنك استخدام متغيرات البيئة لتخزين معلومات حساسة مثل كلمات المرور ومفاتيح API

6. قم بتشغيل الواجهة الخلفية:
   - للتطوير:
     ```bash
     python src/main.py
     ```
   - للإنتاج، يُفضل استخدام Gunicorn:
     ```bash
     pip install gunicorn
     gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
     ```

### 2. إعداد الواجهة الأمامية (Frontend)

1. انتقل إلى مجلد الواجهة الأمامية:
   ```bash
   cd frontend
   ```

2. قم بتثبيت المتطلبات:
   ```bash
   npm install
   # أو
   pnpm install
   # أو
   yarn install
   ```

3. قم بإنشاء ملف `.env` لتحديد عنوان API:
   ```
   VITE_API_URL=http://your-backend-domain.com/api
   ```
   - استبدل `your-backend-domain.com` بعنوان الواجهة الخلفية الخاص بك

4. قم ببناء الواجهة الأمامية للإنتاج:
   ```bash
   npm run build
   # أو
   pnpm run build
   # أو
   yarn build
   ```

5. قم بنشر المحتوى المُنشأ في مجلد `dist` على خادم الويب الخاص بك.

### 3. إعداد خادم الويب

#### باستخدام Nginx (موصى به)

1. قم بتثبيت Nginx:
   ```bash
   sudo apt update
   sudo apt install nginx
   ```

2. قم بإنشاء ملف تكوين للموقع:
   ```bash
   sudo nano /etc/nginx/sites-available/escrow-market
   ```

3. أضف التكوين التالي:
   ```nginx
   # تكوين الواجهة الأمامية
   server {
       listen 80;
       server_name your-frontend-domain.com;
       
       root /path/to/frontend/dist;
       index index.html;
       
       location / {
           try_files $uri $uri/ /index.html;
       }
   }
   
   # تكوين الواجهة الخلفية
   server {
       listen 80;
       server_name your-backend-domain.com;
       
       location / {
           proxy_pass http://localhost:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```
   - استبدل `your-frontend-domain.com` و `your-backend-domain.com` بالنطاقات الخاصة بك
   - استبدل `/path/to/frontend/dist` بالمسار الكامل لمجلد `dist` الذي تم إنشاؤه

4. قم بتفعيل التكوين:
   ```bash
   sudo ln -s /etc/nginx/sites-available/escrow-market /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

### 4. إعداد SSL (موصى به)

1. قم بتثبيت Certbot:
   ```bash
   sudo apt install certbot python3-certbot-nginx
   ```

2. قم بإنشاء شهادات SSL:
   ```bash
   sudo certbot --nginx -d your-frontend-domain.com -d your-backend-domain.com
   ```

### 5. إعداد Process Manager (للواجهة الخلفية)

يُفضل استخدام مدير عمليات مثل PM2 أو Supervisor لضمان استمرار تشغيل الواجهة الخلفية.

#### باستخدام PM2

1. قم بتثبيت PM2:
   ```bash
   sudo npm install -g pm2
   ```

2. قم بإنشاء ملف تكوين `ecosystem.config.js`:
   ```javascript
   module.exports = {
     apps: [{
       name: "escrow-backend",
       cwd: "/path/to/backend",
       script: "gunicorn",
       args: "-w 4 -b 0.0.0.0:5000 src.main:app",
       interpreter: "/path/to/backend/venv/bin/python",
       env: {
         SECRET_KEY: "your-secret-key",
         FLASK_ENV: "production"
       }
     }]
   };
   ```

3. قم بتشغيل التطبيق:
   ```bash
   pm2 start ecosystem.config.js
   ```

4. قم بتكوين PM2 للتشغيل التلقائي عند إعادة تشغيل النظام:
   ```bash
   pm2 startup
   pm2 save
   ```

## ملاحظات إضافية

- تأكد من فتح المنافذ المطلوبة في جدار الحماية (80 و 443 للويب)
- قم بإعداد نسخ احتياطي منتظم لقاعدة البيانات
- قم بتحديث النظام والتبعيات بانتظام لتجنب الثغرات الأمنية

## الدعم

إذا واجهت أي مشاكل أو كانت لديك أسئلة، يرجى التواصل معنا على [support@escrowmarket.com](mailto:support@escrowmarket.com).

