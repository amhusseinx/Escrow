# tests/test_api.py
import pytest
import json
import jwt
from datetime import datetime, timedelta
from src.main import app
from src.models.user import User, db
from src.models.product import Product, Category
from src.models.transaction import Transaction, Dispute, Review

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            # Create test data
            create_test_data()
            yield client
            db.drop_all()

def create_test_data():
    # Create admin user
    admin = User(
        username='admin',
        email='admin@example.com',
        role='admin',
        is_active=True
    )
    admin.set_password('admin123')
    
    # Create seller user
    seller = User(
        username='seller',
        email='seller@example.com',
        role='seller',
        is_active=True
    )
    seller.set_password('seller123')
    
    # Create buyer user
    buyer = User(
        username='buyer',
        email='buyer@example.com',
        role='buyer',
        is_active=True
    )
    buyer.set_password('buyer123')
    
    # Create category
    category = Category(
        name='Games',
        description='Video games and game accounts'
    )
    
    db.session.add_all([admin, seller, buyer, category])
    db.session.commit()
    
    # Create product
    product = Product(
        title='Fortnite Account',
        description='Fortnite account with rare skins',
        price=99.99,
        seller_id=seller.id,
        category_id=category.id,
        status='active'
    )
    
    db.session.add(product)
    db.session.commit()

def get_auth_token(client, username, password):
    response = client.post('/api/auth/login', json={
        'username': username,
        'password': password
    })
    return json.loads(response.data)['token']

def test_health_check(client):
    response = client.get('/api/health')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['status'] == 'ok'
    assert data['message'] == 'API is running'

def test_register_user(client):
    response = client.post('/api/auth/register', json={
        'username': 'testuser',
        'email': 'test@example.com',
        'password': 'test123',
        'full_name': 'Test User'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['message'] == 'User registered successfully!'
    
    # Check if user exists in database
    with app.app_context():
        user = User.query.filter_by(username='testuser').first()
        assert user is not None
        assert user.email == 'test@example.com'
        assert user.full_name == 'Test User'
        assert user.role == 'buyer'  # Default role

def test_login_user(client):
    response = client.post('/api/auth/login', json={
        'username': 'admin',
        'password': 'admin123'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'token' in data
    assert 'user' in data
    assert data['user']['username'] == 'admin'
    assert data['user']['role'] == 'admin'
    
    # Verify token
    token = data['token']
    decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
    assert decoded['username'] == 'admin'
    assert decoded['role'] == 'admin'

def test_get_me(client):
    token = get_auth_token(client, 'admin', 'admin123')
    response = client.get('/api/auth/me', headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['username'] == 'admin'
    assert data['role'] == 'admin'

def test_get_users_as_admin(client):
    token = get_auth_token(client, 'admin', 'admin123')
    response = client.get('/api/users', headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) == 3  # admin, seller, buyer

def test_get_users_as_non_admin(client):
    token = get_auth_token(client, 'seller', 'seller123')
    response = client.get('/api/users', headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 403  # Forbidden

def test_get_categories(client):
    response = client.get('/api/categories')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) == 1
    assert data[0]['name'] == 'Games'

def test_create_category(client):
    token = get_auth_token(client, 'admin', 'admin123')
    response = client.post('/api/categories', json={
        'name': 'Software',
        'description': 'Software and applications'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['name'] == 'Software'
    assert data['description'] == 'Software and applications'

def test_get_products(client):
    response = client.get('/api/products')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) == 1
    assert data[0]['title'] == 'Fortnite Account'
    assert data[0]['price'] == 99.99

def test_create_product(client):
    token = get_auth_token(client, 'seller', 'seller123')
    
    # Get seller ID
    with app.app_context():
        seller = User.query.filter_by(username='seller').first()
        category = Category.query.filter_by(name='Games').first()
    
    response = client.post('/api/products', json={
        'title': 'Minecraft Account',
        'description': 'Minecraft premium account',
        'price': 29.99,
        'seller_id': seller.id,
        'category_id': category.id
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['title'] == 'Minecraft Account'
    assert data['price'] == 29.99
    assert data['seller'] == 'seller'
    assert data['category'] == 'Games'

def test_create_transaction(client):
    token = get_auth_token(client, 'buyer', 'buyer123')
    
    # Get buyer ID and product ID
    with app.app_context():
        buyer = User.query.filter_by(username='buyer').first()
        product = Product.query.filter_by(title='Fortnite Account').first()
    
    response = client.post('/api/transactions', json={
        'product_id': product.id,
        'buyer_id': buyer.id,
        'payment_method': 'credit_card'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['product_title'] == 'Fortnite Account'
    assert data['buyer_username'] == 'buyer'
    assert data['seller_username'] == 'seller'
    assert data['amount'] == 99.99
    assert data['status'] == 'pending'
    
    # Check if product status is updated
    with app.app_context():
        product = Product.query.filter_by(title='Fortnite Account').first()
        assert product.status == 'pending'

def test_update_transaction_status(client):
    # First create a transaction
    token_buyer = get_auth_token(client, 'buyer', 'buyer123')
    
    with app.app_context():
        buyer = User.query.filter_by(username='buyer').first()
        product = Product.query.filter_by(title='Fortnite Account').first()
    
    response = client.post('/api/transactions', json={
        'product_id': product.id,
        'buyer_id': buyer.id,
        'payment_method': 'credit_card'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    transaction_id = json.loads(response.data)['id']
    
    # Now update the transaction status
    token_seller = get_auth_token(client, 'seller', 'seller123')
    response = client.put(f'/api/transactions/{transaction_id}', json={
        'status': 'delivered'
    }, headers={
        'Authorization': f'Bearer {token_seller}'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['status'] == 'delivered'
    
    # Complete the transaction
    response = client.put(f'/api/transactions/{transaction_id}', json={
        'status': 'completed'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['status'] == 'completed'
    assert data['completed_at'] is not None
    
    # Check if product status is updated
    with app.app_context():
        product = Product.query.filter_by(title='Fortnite Account').first()
        assert product.status == 'sold'

def test_create_dispute(client):
    # First create a transaction
    token_buyer = get_auth_token(client, 'buyer', 'buyer123')
    
    with app.app_context():
        buyer = User.query.filter_by(username='buyer').first()
        product = Product.query.filter_by(title='Fortnite Account').first()
    
    response = client.post('/api/transactions', json={
        'product_id': product.id,
        'buyer_id': buyer.id,
        'payment_method': 'credit_card'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    transaction_id = json.loads(response.data)['id']
    
    # Create a dispute
    response = client.post('/api/disputes', json={
        'transaction_id': transaction_id,
        'opened_by_id': buyer.id,
        'reason': 'Product not as described'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['transaction_id'] == transaction_id
    assert data['opened_by_username'] == 'buyer'
    assert data['reason'] == 'Product not as described'
    assert data['status'] == 'open'
    
    # Check if transaction status is updated
    with app.app_context():
        transaction = Transaction.query.get(transaction_id)
        assert transaction.status == 'disputed'

def test_resolve_dispute(client):
    # First create a transaction and dispute
    token_buyer = get_auth_token(client, 'buyer', 'buyer123')
    token_admin = get_auth_token(client, 'admin', 'admin123')
    
    with app.app_context():
        buyer = User.query.filter_by(username='buyer').first()
        admin = User.query.filter_by(username='admin').first()
        product = Product.query.filter_by(title='Fortnite Account').first()
    
    response = client.post('/api/transactions', json={
        'product_id': product.id,
        'buyer_id': buyer.id,
        'payment_method': 'credit_card'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    transaction_id = json.loads(response.data)['id']
    
    response = client.post('/api/disputes', json={
        'transaction_id': transaction_id,
        'opened_by_id': buyer.id,
        'reason': 'Product not as described'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    dispute_id = json.loads(response.data)['id']
    
    # Resolve the dispute
    response = client.put(f'/api/disputes/{dispute_id}', json={
        'status': 'resolved',
        'resolution': 'Refund issued to buyer',
        'resolved_by_id': admin.id,
        'resolution_action': 'refund'
    }, headers={
        'Authorization': f'Bearer {token_admin}'
    })
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['status'] == 'resolved'
    assert data['resolution'] == 'Refund issued to buyer'
    assert data['resolved_by_username'] == 'admin'
    assert data['resolved_at'] is not None
    
    # Check if transaction status is updated
    with app.app_context():
        transaction = Transaction.query.get(transaction_id)
        assert transaction.status == 'refunded'
        
        # Check if product status is updated
        product = Product.query.filter_by(title='Fortnite Account').first()
        assert product.status == 'active'

def test_create_review(client):
    token_buyer = get_auth_token(client, 'buyer', 'buyer123')
    
    with app.app_context():
        buyer = User.query.filter_by(username='buyer').first()
        product = Product.query.filter_by(title='Fortnite Account').first()
    
    response = client.post('/api/reviews', json={
        'product_id': product.id,
        'user_id': buyer.id,
        'rating': 5,
        'comment': 'Great product!'
    }, headers={
        'Authorization': f'Bearer {token_buyer}'
    })
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['product_title'] == 'Fortnite Account'
    assert data['user_username'] == 'buyer'
    assert data['rating'] == 5
    assert data['comment'] == 'Great product!'
    
    # Check if product rating is updated
    with app.app_context():
        product = Product.query.filter_by(title='Fortnite Account').first()
        assert product.rating == 5
        assert product.rating_count == 1
        
        # Check if seller rating is updated
        seller = User.query.filter_by(username='seller').first()
        assert seller.rating == 5
        assert seller.rating_count == 1

