from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending')  # pending, paid, delivered, completed, disputed, refunded, cancelled
    escrow_id = db.Column(db.String(100), nullable=True)  # ID from payment processor
    payment_method = db.Column(db.String(50), nullable=True)
    delivery_method = db.Column(db.String(50), nullable=True)
    delivery_details = db.Column(db.Text, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    product = db.relationship('Product', backref='transactions')
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='purchases')
    seller = db.relationship('User', foreign_keys=[seller_id], backref='sales')
    # dispute = db.relationship('Dispute', backref='transaction', uselist=False, lazy=True)
    
    def __repr__(self):
        return f'<Transaction {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'product_title': self.product.title if self.product else None,
            'buyer_id': self.buyer_id,
            'buyer_username': self.buyer.username if self.buyer else None,
            'seller_id': self.seller_id,
            'seller_username': self.seller.username if self.seller else None,
            'amount': self.amount,
            'status': self.status,
            'escrow_id': self.escrow_id,
            'payment_method': self.payment_method,
            'delivery_method': self.delivery_method,
            'delivery_details': self.delivery_details,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class Dispute(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transaction.id'), nullable=False)
    opened_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='open')  # open, resolved, closed
    resolution = db.Column(db.Text, nullable=True)
    resolved_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    transaction = db.relationship('Transaction', backref='dispute')
    opened_by = db.relationship('User', foreign_keys=[opened_by_id], backref='opened_disputes')
    resolved_by = db.relationship('User', foreign_keys=[resolved_by_id], backref='resolved_disputes')
    
    def __repr__(self):
        return f'<Dispute {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'transaction_id': self.transaction_id,
            'opened_by_id': self.opened_by_id,
            'opened_by_username': self.opened_by.username if self.opened_by else None,
            'reason': self.reason,
            'status': self.status,
            'resolution': self.resolution,
            'resolved_by_id': self.resolved_by_id,
            'resolved_by_username': self.resolved_by.username if self.resolved_by else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None
        }

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    product = db.relationship('Product', backref='reviews')
    user = db.relationship('User', backref='reviews')
    
    def __repr__(self):
        return f'<Review {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'product_title': self.product.title if self.product else None,
            'user_id': self.user_id,
            'user_username': self.user.username if self.user else None,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

