from flask import Blueprint, jsonify, request
from src.models.transaction import Transaction, Dispute, Review, db
from src.models.product import Product
from src.models.user import User
from flask_cors import CORS
from datetime import datetime

transaction_bp = Blueprint('transaction', __name__)
CORS(transaction_bp)

# Transaction routes
@transaction_bp.route('/transactions', methods=['GET'])
def get_transactions():
    buyer_id = request.args.get('buyer_id', type=int)
    seller_id = request.args.get('seller_id', type=int)
    product_id = request.args.get('product_id', type=int)
    status = request.args.get('status')
    
    query = Transaction.query
    
    if buyer_id:
        query = query.filter_by(buyer_id=buyer_id)
    if seller_id:
        query = query.filter_by(seller_id=seller_id)
    if product_id:
        query = query.filter_by(product_id=product_id)
    if status:
        query = query.filter_by(status=status)
    
    transactions = query.all()
    return jsonify([transaction.to_dict() for transaction in transactions])

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['GET'])
def get_transaction(transaction_id):
    transaction = Transaction.query.get_or_404(transaction_id)
    return jsonify(transaction.to_dict())

@transaction_bp.route('/transactions', methods=['POST'])
def create_transaction():
    data = request.json
    
    # Check if product exists and is available
    product = Product.query.get_or_404(data['product_id'])
    if product.status != 'active':
        return jsonify({'error': 'Product is not available for purchase'}), 400
    
    # Create transaction
    transaction = Transaction(
        product_id=data['product_id'],
        buyer_id=data['buyer_id'],
        seller_id=product.seller_id,
        amount=product.price,
        status='pending',
        payment_method=data.get('payment_method'),
        delivery_method=data.get('delivery_method'),
        delivery_details=data.get('delivery_details'),
        notes=data.get('notes')
    )
    
    # Update product status
    product.status = 'pending'
    
    db.session.add(transaction)
    db.session.commit()
    return jsonify(transaction.to_dict()), 201

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['PUT'])
def update_transaction(transaction_id):
    transaction = Transaction.query.get_or_404(transaction_id)
    data = request.json
    
    # Update transaction status
    old_status = transaction.status
    new_status = data.get('status', old_status)
    
    if new_status != old_status:
        # Handle status transitions
        if new_status == 'paid':
            # Buyer has paid, money is in escrow
            pass
        elif new_status == 'delivered':
            # Seller has delivered the product
            pass
        elif new_status == 'completed':
            # Buyer has confirmed receipt, release payment to seller
            transaction.completed_at = datetime.utcnow()
            
            # Update product status
            product = Product.query.get(transaction.product_id)
            if product:
                product.status = 'sold'
        elif new_status == 'disputed':
            # Transaction is in dispute
            pass
        elif new_status == 'refunded':
            # Money returned to buyer
            
            # Update product status
            product = Product.query.get(transaction.product_id)
            if product:
                product.status = 'active'
        elif new_status == 'cancelled':
            # Transaction cancelled
            
            # Update product status
            product = Product.query.get(transaction.product_id)
            if product:
                product.status = 'active'
    
    transaction.status = new_status
    transaction.payment_method = data.get('payment_method', transaction.payment_method)
    transaction.delivery_method = data.get('delivery_method', transaction.delivery_method)
    transaction.delivery_details = data.get('delivery_details', transaction.delivery_details)
    transaction.notes = data.get('notes', transaction.notes)
    transaction.escrow_id = data.get('escrow_id', transaction.escrow_id)
    
    db.session.commit()
    return jsonify(transaction.to_dict())

# Dispute routes
@transaction_bp.route('/disputes', methods=['GET'])
def get_disputes():
    transaction_id = request.args.get('transaction_id', type=int)
    opened_by_id = request.args.get('opened_by_id', type=int)
    status = request.args.get('status')
    
    query = Dispute.query
    
    if transaction_id:
        query = query.filter_by(transaction_id=transaction_id)
    if opened_by_id:
        query = query.filter_by(opened_by_id=opened_by_id)
    if status:
        query = query.filter_by(status=status)
    
    disputes = query.all()
    return jsonify([dispute.to_dict() for dispute in disputes])

@transaction_bp.route('/disputes/<int:dispute_id>', methods=['GET'])
def get_dispute(dispute_id):
    dispute = Dispute.query.get_or_404(dispute_id)
    return jsonify(dispute.to_dict())

@transaction_bp.route('/disputes', methods=['POST'])
def create_dispute():
    data = request.json
    
    # Check if transaction exists
    transaction = Transaction.query.get_or_404(data['transaction_id'])
    
    # Create dispute
    dispute = Dispute(
        transaction_id=data['transaction_id'],
        opened_by_id=data['opened_by_id'],
        reason=data['reason']
    )
    
    # Update transaction status
    transaction.status = 'disputed'
    
    db.session.add(dispute)
    db.session.commit()
    return jsonify(dispute.to_dict()), 201

@transaction_bp.route('/disputes/<int:dispute_id>', methods=['PUT'])
def update_dispute(dispute_id):
    dispute = Dispute.query.get_or_404(dispute_id)
    data = request.json
    
    # Update dispute status
    old_status = dispute.status
    new_status = data.get('status', old_status)
    
    if new_status != old_status and new_status in ['resolved', 'closed']:
        dispute.resolved_at = datetime.utcnow()
        dispute.resolved_by_id = data.get('resolved_by_id')
        
        # Update transaction status based on resolution
        transaction = Transaction.query.get(dispute.transaction_id)
        if transaction:
            resolution_action = data.get('resolution_action')
            if resolution_action == 'refund':
                transaction.status = 'refunded'
                
                # Update product status
                product = Product.query.get(transaction.product_id)
                if product:
                    product.status = 'active'
            elif resolution_action == 'complete':
                transaction.status = 'completed'
                transaction.completed_at = datetime.utcnow()
                
                # Update product status
                product = Product.query.get(transaction.product_id)
                if product:
                    product.status = 'sold'
    
    dispute.status = new_status
    dispute.resolution = data.get('resolution', dispute.resolution)
    
    db.session.commit()
    return jsonify(dispute.to_dict())

# Review routes
@transaction_bp.route('/reviews', methods=['GET'])
def get_reviews():
    product_id = request.args.get('product_id', type=int)
    user_id = request.args.get('user_id', type=int)
    
    query = Review.query
    
    if product_id:
        query = query.filter_by(product_id=product_id)
    if user_id:
        query = query.filter_by(user_id=user_id)
    
    reviews = query.all()
    return jsonify([review.to_dict() for review in reviews])

@transaction_bp.route('/reviews/<int:review_id>', methods=['GET'])
def get_review(review_id):
    review = Review.query.get_or_404(review_id)
    return jsonify(review.to_dict())

@transaction_bp.route('/reviews', methods=['POST'])
def create_review():
    data = request.json
    
    # Check if product exists
    product = Product.query.get_or_404(data['product_id'])
    
    # Create review
    review = Review(
        product_id=data['product_id'],
        user_id=data['user_id'],
        rating=data['rating'],
        comment=data.get('comment')
    )
    
    # Update product rating
    product.rating = product.rating + data['rating']
    product.rating_count = product.rating_count + 1
    
    # Update seller rating
    seller = User.query.get(product.seller_id)
    if seller:
        seller.rating = seller.rating + data['rating']
        seller.rating_count = seller.rating_count + 1
    
    db.session.add(review)
    db.session.commit()
    return jsonify(review.to_dict()), 201

@transaction_bp.route('/reviews/<int:review_id>', methods=['PUT'])
def update_review(review_id):
    review = Review.query.get_or_404(review_id)
    data = request.json
    
    # Update product and seller ratings if rating changed
    if 'rating' in data and data['rating'] != review.rating:
        product = Product.query.get(review.product_id)
        if product:
            # Subtract old rating and add new rating
            product.rating = product.rating - review.rating + data['rating']
        
        # Update seller rating
        if product and product.seller_id:
            seller = User.query.get(product.seller_id)
            if seller:
                # Subtract old rating and add new rating
                seller.rating = seller.rating - review.rating + data['rating']
    
    review.rating = data.get('rating', review.rating)
    review.comment = data.get('comment', review.comment)
    
    db.session.commit()
    return jsonify(review.to_dict())

@transaction_bp.route('/reviews/<int:review_id>', methods=['DELETE'])
def delete_review(review_id):
    review = Review.query.get_or_404(review_id)
    
    # Update product rating
    product = Product.query.get(review.product_id)
    if product:
        product.rating = product.rating - review.rating
        product.rating_count = product.rating_count - 1
    
    # Update seller rating
    if product and product.seller_id:
        seller = User.query.get(product.seller_id)
        if seller:
            seller.rating = seller.rating - review.rating
            seller.rating_count = seller.rating_count - 1
    
    db.session.delete(review)
    db.session.commit()
    return '', 204

