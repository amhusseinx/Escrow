from flask import Blueprint, jsonify, request, current_app
from src.models.user import User, db
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from datetime import datetime, timedelta
from functools import wraps
from flask_cors import CORS

user_bp = Blueprint('user', __name__)
CORS(user_bp)

# Authentication decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Get token from header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        
        try:
            # Decode token
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
            
            if not current_user:
                return jsonify({'message': 'User not found!'}), 401
            
            if not current_user.is_active:
                return jsonify({'message': 'User account is inactive!'}), 401
            
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired!'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Invalid token!'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

# Authentication routes
@user_bp.route('/auth/register', methods=['POST'])
def register():
    data = request.json
    
    # Check if username or email already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists!'}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists!'}), 400
    
    # Create new user
    user = User(
        username=data['username'],
        email=data['email'],
        role=data.get('role', 'buyer'),
        full_name=data.get('full_name'),
        avatar=data.get('avatar'),
        bio=data.get('bio')
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'message': 'User registered successfully!'}), 201

@user_bp.route('/auth/login', methods=['POST'])
def login():
    data = request.json
    
    # Check if username/email and password are provided
    if not data.get('username') and not data.get('email'):
        return jsonify({'message': 'Username or email is required!'}), 400
    
    if not data.get('password'):
        return jsonify({'message': 'Password is required!'}), 400
    
    # Find user by username or email
    user = None
    if data.get('username'):
        user = User.query.filter_by(username=data['username']).first()
    else:
        user = User.query.filter_by(email=data['email']).first()
    
    if not user:
        return jsonify({'message': 'User not found!'}), 401
    
    # Check password
    if not user.check_password(data['password']):
        return jsonify({'message': 'Invalid password!'}), 401
    
    if not user.is_active:
        return jsonify({'message': 'User account is inactive!'}), 401
    
    # Generate token
    token = jwt.encode({
        'user_id': user.id,
        'username': user.username,
        'role': user.role,
        'exp': datetime.utcnow() + timedelta(hours=24)
    }, current_app.config['SECRET_KEY'], algorithm="HS256")
    
    return jsonify({
        'token': token,
        'user': user.to_dict()
    })

@user_bp.route('/auth/me', methods=['GET'])
@token_required
def get_me(current_user):
    return jsonify(current_user.to_dict())

# User routes
@user_bp.route('/users', methods=['GET'])
@token_required
def get_users(current_user):
    # Only admins can view all users
    if current_user.role != 'admin':
        return jsonify({'message': 'Permission denied!'}), 403
    
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
def update_user(current_user, user_id):
    # Users can only update their own profile, admins can update any profile
    if current_user.id != user_id and current_user.role != 'admin':
        return jsonify({'message': 'Permission denied!'}), 403
    
    user = User.query.get_or_404(user_id)
    data = request.json
    
    # Update user fields
    if 'username' in data and data['username'] != user.username:
        # Check if username already exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'message': 'Username already exists!'}), 400
        user.username = data['username']
    
    if 'email' in data and data['email'] != user.email:
        # Check if email already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'message': 'Email already exists!'}), 400
        user.email = data['email']
    
    if 'password' in data:
        user.set_password(data['password'])
    
    if 'full_name' in data:
        user.full_name = data['full_name']
    
    if 'avatar' in data:
        user.avatar = data['avatar']
    
    if 'bio' in data:
        user.bio = data['bio']
    
    # Only admins can update role and active status
    if current_user.role == 'admin':
        if 'role' in data:
            user.role = data['role']
        
        if 'is_active' in data:
            user.is_active = data['is_active']
    
    db.session.commit()
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
@token_required
def delete_user(current_user, user_id):
    # Only admins can delete users
    if current_user.role != 'admin':
        return jsonify({'message': 'Permission denied!'}), 403
    
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return '', 204
