from flask import Blueprint, jsonify, request
from src.models.product import Product, Category, db
from flask_cors import CORS

product_bp = Blueprint('product', __name__)
CORS(product_bp)

# Category routes
@product_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = Category.query.all()
    return jsonify([category.to_dict() for category in categories])

@product_bp.route('/categories/<int:category_id>', methods=['GET'])
def get_category(category_id):
    category = Category.query.get_or_404(category_id)
    return jsonify(category.to_dict())

@product_bp.route('/categories', methods=['POST'])
def create_category():
    data = request.json
    category = Category(
        name=data['name'],
        description=data.get('description'),
        image=data.get('image')
    )
    db.session.add(category)
    db.session.commit()
    return jsonify(category.to_dict()), 201

@product_bp.route('/categories/<int:category_id>', methods=['PUT'])
def update_category(category_id):
    category = Category.query.get_or_404(category_id)
    data = request.json
    category.name = data.get('name', category.name)
    category.description = data.get('description', category.description)
    category.image = data.get('image', category.image)
    db.session.commit()
    return jsonify(category.to_dict())

@product_bp.route('/categories/<int:category_id>', methods=['DELETE'])
def delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    db.session.delete(category)
    db.session.commit()
    return '', 204

# Product routes
@product_bp.route('/products', methods=['GET'])
def get_products():
    category_id = request.args.get('category_id', type=int)
    seller_id = request.args.get('seller_id', type=int)
    status = request.args.get('status')
    
    query = Product.query
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    if seller_id:
        query = query.filter_by(seller_id=seller_id)
    if status:
        query = query.filter_by(status=status)
    
    products = query.all()
    return jsonify([product.to_dict() for product in products])

@product_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict())

@product_bp.route('/products', methods=['POST'])
def create_product():
    data = request.json
    product = Product(
        title=data['title'],
        description=data['description'],
        price=data['price'],
        image=data.get('image'),
        seller_id=data['seller_id'],
        category_id=data['category_id'],
        status=data.get('status', 'active')
    )
    db.session.add(product)
    db.session.commit()
    return jsonify(product.to_dict()), 201

@product_bp.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    product = Product.query.get_or_404(product_id)
    data = request.json
    product.title = data.get('title', product.title)
    product.description = data.get('description', product.description)
    product.price = data.get('price', product.price)
    product.image = data.get('image', product.image)
    product.category_id = data.get('category_id', product.category_id)
    product.status = data.get('status', product.status)
    db.session.commit()
    return jsonify(product.to_dict())

@product_bp.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return '', 204

