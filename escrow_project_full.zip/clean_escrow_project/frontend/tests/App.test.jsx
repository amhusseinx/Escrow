// tests/App.test.jsx
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import App from '../src/App';

// Mock components
vi.mock('@/components/ui/button.jsx', () => ({
  Button: ({ children, onClick, className }) => (
    <button onClick={onClick} className={className} data-testid="button">
      {children}
    </button>
  ),
}));

vi.mock('lucide-react', () => ({
  Home: () => <div data-testid="icon-home">Home Icon</div>,
  Search: () => <div data-testid="icon-search">Search Icon</div>,
  User: () => <div data-testid="icon-user">User Icon</div>,
  ShoppingCart: () => <div data-testid="icon-cart">Cart Icon</div>,
  LogIn: () => <div data-testid="icon-login">Login Icon</div>,
  Menu: () => <div data-testid="icon-menu">Menu Icon</div>,
  X: () => <div data-testid="icon-close">Close Icon</div>,
}));

describe('App Component', () => {
  it('renders the header with logo', () => {
    render(<App />);
    expect(screen.getByText(/EscrowMarket/i)).toBeInTheDocument();
  });

  it('toggles mobile menu when menu button is clicked', () => {
    render(<App />);
    const menuButton = screen.getByTestId('icon-menu').closest('button');
    
    // Menu is initially hidden on mobile
    expect(screen.getByRole('navigation').className).toContain('hidden');
    
    // Click to open menu
    fireEvent.click(menuButton);
    
    // Menu should now be visible
    expect(screen.getByRole('navigation').className).toContain('flex');
    
    // Click again to close
    fireEvent.click(menuButton);
    
    // Menu should be hidden again
    expect(screen.getByRole('navigation').className).toContain('hidden');
  });

  it('renders hero section with call-to-action buttons', () => {
    render(<App />);
    expect(screen.getByText(/سوق آمن للمعاملات الرقمية/i)).toBeInTheDocument();
    expect(screen.getByText(/إنشاء حساب/i)).toBeInTheDocument();
    expect(screen.getByText(/استكشاف المنتجات/i)).toBeInTheDocument();
  });

  it('renders how it works section with 4 steps', () => {
    render(<App />);
    expect(screen.getByText(/كيف يعمل نظام Escrow؟/i)).toBeInTheDocument();
    expect(screen.getByText(/التسجيل/i)).toBeInTheDocument();
    expect(screen.getByText(/الدفع/i)).toBeInTheDocument();
    expect(screen.getByText(/التسليم/i)).toBeInTheDocument();
    expect(screen.getByText(/التأكيد/i)).toBeInTheDocument();
  });

  it('renders featured categories section', () => {
    render(<App />);
    expect(screen.getByText(/الفئات المميزة/i)).toBeInTheDocument();
  });

  it('renders trending products section', () => {
    render(<App />);
    expect(screen.getByText(/المنتجات الرائجة/i)).toBeInTheDocument();
  });

  it('renders top sellers section', () => {
    render(<App />);
    expect(screen.getByText(/أفضل البائعين/i)).toBeInTheDocument();
  });

  it('renders testimonials section', () => {
    render(<App />);
    expect(screen.getByText(/آراء العملاء/i)).toBeInTheDocument();
  });

  it('renders call to action section', () => {
    render(<App />);
    expect(screen.getByText(/ابدأ البيع أو الشراء الآن!/i)).toBeInTheDocument();
  });

  it('renders footer with copyright information', () => {
    render(<App />);
    expect(screen.getByText(/جميع الحقوق محفوظة/i)).toBeInTheDocument();
  });
});

