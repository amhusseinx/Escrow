import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import './App.css'
import { Home, Search, User, ShoppingCart, LogIn, Menu, X } from 'lucide-react'

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header mobileMenuOpen={mobileMenuOpen} toggleMobileMenu={toggleMobileMenu} />
      <main className="flex-grow">
        <HeroSection />
        <HowItWorksSection />
        <FeaturedCategoriesSection />
        <TrendingProductsSection />
        <TopSellersSection />
        <TestimonialsSection />
        <CallToActionSection />
      </main>
      <Footer />
    </div>
  )
}

function Header({ mobileMenuOpen, toggleMobileMenu }) {
  return (
    <header className="bg-accent text-white py-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="logo text-2xl font-bold">
            <a href="/">Escrow<span className="text-primary">Market</span></a>
          </div>
          
          <button className="md:hidden" onClick={toggleMobileMenu}>
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          
          <nav className={`${mobileMenuOpen ? 'flex' : 'hidden'} md:flex flex-col md:flex-row absolute md:relative top-16 md:top-0 left-0 right-0 bg-accent md:bg-transparent p-4 md:p-0 shadow-md md:shadow-none`}>
            <ul className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-4 w-full md:w-auto">
              <li><a href="/" className="block px-3 py-2 rounded-md hover:bg-primary/20 transition-colors">الرئيسية</a></li>
              <li><a href="/store" className="block px-3 py-2 rounded-md hover:bg-primary/20 transition-colors">المتجر</a></li>
              <li><a href="/how-it-works" className="block px-3 py-2 rounded-md hover:bg-primary/20 transition-colors">كيف يعمل</a></li>
              <li><a href="/contact" className="block px-3 py-2 rounded-md hover:bg-primary/20 transition-colors">اتصل بنا</a></li>
            </ul>
            
            <div className="flex items-center mt-4 md:mt-0 md:mr-4">
              <div className="relative flex items-center bg-white/10 rounded-md px-2 py-1 w-full md:w-auto">
                <input type="text" placeholder="ابحث عن منتجات..." className="bg-transparent border-none outline-none text-white placeholder-white/70 w-full" />
                <button className="text-white"><Search size={18} /></button>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-center mt-4 md:mt-0 space-y-2 md:space-y-0 md:space-x-2">
              <Button variant="outline" className="w-full md:w-auto border-white text-white hover:bg-white/10">تسجيل الدخول</Button>
              <Button className="w-full md:w-auto bg-primary hover:bg-primary/90">بيع منتج</Button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}

function HeroSection() {
  return (
    <section className="hero">
      <div className="container mx-auto px-4">
        <div className="hero-content">
          <h1 className="hero-title">سوق آمن للمعاملات الرقمية</h1>
          <p className="hero-description">اشتر وبع بأمان مع نظام Escrow للدفع الآمن. نضمن حماية كل من المشتري والبائع في جميع المعاملات.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
            <Button className="bg-primary hover:bg-primary/90 text-white">إنشاء حساب</Button>
            <Button variant="outline" className="border-white text-white hover:bg-white/10">استكشاف المنتجات</Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">كيف يعمل نظام Escrow؟</h2>
        <div className="steps">
          <div className="step">
            <div className="step-icon">
              <User className="mx-auto" size={48} />
            </div>
            <h3 className="step-title">التسجيل</h3>
            <p className="step-description">سجل مجاناً للوصول إلى جميع ميزات الموقع وبدء عمليات البيع والشراء الآمنة.</p>
          </div>
          
          <div className="step">
            <div className="step-icon">
              <ShoppingCart className="mx-auto" size={48} />
            </div>
            <h3 className="step-title">الدفع</h3>
            <p className="step-description">ادفع باستخدام طريقة الدفع المفضلة لديك. سنحتفظ بالمبلغ في حساب Escrow آمن.</p>
          </div>
          
          <div className="step">
            <div className="step-icon">
              <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 13l4 4L19 7"></path>
              </svg>
            </div>
            <h3 className="step-title">التسليم</h3>
            <p className="step-description">يقوم البائع بتسليم المنتج الرقمي. بعض المنتجات يتم تسليمها فورياً.</p>
          </div>
          
          <div className="step">
            <div className="step-icon">
              <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            </div>
            <h3 className="step-title">التأكيد</h3>
            <p className="step-description">أكد استلام المنتج بشكل صحيح. سيتم تحويل المبلغ إلى البائع بعد التأكيد.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeaturedCategoriesSection() {
  const categories = [
    { id: 1, name: 'حسابات الألعاب', image: 'https://via.placeholder.com/300x200' },
    { id: 2, name: 'العملات الرقمية', image: 'https://via.placeholder.com/300x200' },
    { id: 3, name: 'البرمجيات والتطبيقات', image: 'https://via.placeholder.com/300x200' },
    { id: 4, name: 'التصاميم والجرافيك', image: 'https://via.placeholder.com/300x200' },
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="section-title">الفئات المميزة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map(category => (
            <div key={category.id} className="relative rounded-lg overflow-hidden shadow-md transition-transform hover:-translate-y-2 hover:shadow-lg">
              <img src={category.image} alt={category.name} className="w-full h-48 object-cover" />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <h3 className="text-white text-lg font-semibold">{category.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TrendingProductsSection() {
  const products = [
    { 
      id: 1, 
      name: 'حساب لعبة Fortnite مع سكنات نادرة', 
      price: 99.99, 
      seller: 'GameStore', 
      rating: 4.9, 
      image: 'https://via.placeholder.com/300x200' 
    },
    { 
      id: 2, 
      name: '10,000 عملة ذهبية في لعبة World of Warcraft', 
      price: 49.99, 
      seller: 'GoldMaster', 
      rating: 4.7, 
      image: 'https://via.placeholder.com/300x200' 
    },
    { 
      id: 3, 
      name: 'برنامج تحرير الفيديو الاحترافي', 
      price: 79.99, 
      seller: 'SoftwareHub', 
      rating: 5.0, 
      image: 'https://via.placeholder.com/300x200' 
    },
    { 
      id: 4, 
      name: 'تصميم شعار احترافي مع ملفات المصدر', 
      price: 29.99, 
      seller: 'DesignPro', 
      rating: 4.8, 
      image: 'https://via.placeholder.com/300x200' 
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">المنتجات الرائجة</h2>
        <div className="products">
          {products.map(product => (
            <div key={product.id} className="product">
              <img src={product.image} alt={product.name} className="product-image" />
              <div className="product-content">
                <h3 className="product-title">{product.name}</h3>
                <div className="product-price">${product.price}</div>
                <div className="product-seller">
                  <span>{product.seller}</span>
                  <span className="product-rating mr-2">{'⭐'.repeat(Math.floor(product.rating))} ({product.rating})</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Button className="bg-primary hover:bg-primary/90 text-white">عرض المزيد</Button>
        </div>
      </div>
    </section>
  );
}

function TopSellersSection() {
  const sellers = [
    { id: 1, name: 'GameStore', rating: 4.9, specialty: 'متخصص في حسابات الألعاب والعناصر النادرة', avatar: 'https://via.placeholder.com/100x100' },
    { id: 2, name: 'GoldMaster', rating: 4.7, specialty: 'متخصص في العملات الرقمية والذهب في الألعاب', avatar: 'https://via.placeholder.com/100x100' },
    { id: 3, name: 'SoftwareHub', rating: 5.0, specialty: 'متخصص في البرمجيات والتطبيقات الاحترافية', avatar: 'https://via.placeholder.com/100x100' },
    { id: 4, name: 'DesignPro', rating: 4.8, specialty: 'متخصص في التصاميم والجرافيك الاحترافية', avatar: 'https://via.placeholder.com/100x100' },
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="section-title">أفضل البائعين</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sellers.map(seller => (
            <div key={seller.id} className="bg-white rounded-lg p-6 text-center shadow-md transition-transform hover:-translate-y-2 hover:shadow-lg">
              <img src={seller.avatar} alt={seller.name} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-primary" />
              <h3 className="text-lg font-semibold mb-2">{seller.name}</h3>
              <div className="text-yellow-400 mb-2">{'⭐'.repeat(Math.floor(seller.rating))} ({seller.rating})</div>
              <p className="text-gray-600 text-sm">{seller.specialty}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title">آراء العملاء</h2>
        <div className="max-w-3xl mx-auto bg-white rounded-lg p-8 shadow-md">
          <p className="text-xl italic mb-4">"تجربة رائعة! نظام الدفع الآمن يوفر الثقة التامة في المعاملات. اشتريت العديد من المنتجات الرقمية دون أي مشاكل. أنصح به بشدة لجميع المهتمين بالتجارة الإلكترونية."</p>
          <div className="font-semibold">- أحمد محمد</div>
        </div>
      </div>
    </section>
  );
}

function CallToActionSection() {
  return (
    <section className="py-16 bg-gradient-to-br from-accent to-secondary text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">ابدأ البيع أو الشراء الآن!</h2>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button className="bg-primary hover:bg-primary/90 text-white">إنشاء حساب</Button>
            <Button variant="outline" className="border-white text-white hover:bg-white/10">استكشاف المنتجات</Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-accent text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">EscrowMarket</h3>
            <p className="mb-4">منصة آمنة للمعاملات الرقمية تضمن حماية كل من المشتري والبائع.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-primary transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="#" className="text-white hover:text-primary transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                </svg>
              </a>
              <a href="#" className="text-white hover:text-primary transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">الرئيسية</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">المتجر</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">كيف يعمل</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">اتصل بنا</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">الفئات</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">حسابات الألعاب</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">العملات الرقمية</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">البرمجيات والتطبيقات</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">التصاميم والجرافيك</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">اتصل بنا</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                info@escrowmarket.com
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                +123 456 7890
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                الرياض، المملكة العربية السعودية
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p>&copy; 2025 EscrowMarket. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}

export default App
